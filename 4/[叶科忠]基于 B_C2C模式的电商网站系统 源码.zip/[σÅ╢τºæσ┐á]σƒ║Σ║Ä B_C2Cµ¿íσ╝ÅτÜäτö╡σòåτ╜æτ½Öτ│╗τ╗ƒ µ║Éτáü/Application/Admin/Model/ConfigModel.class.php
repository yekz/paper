<?php

namespace Admin\Model;

/**
 * 配置模型
 */

class ConfigModel extends \Common\Model\ConfigModel {

}
