<?php

namespace Home\Model;

/**
 * 配置模型
 * @author 麦当苗儿 <zuojiazi@vip.qq.com>
 */

class ConfigModel extends \Common\Model\ConfigModel {

}
